#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {
  printf ("Напишите 3 числа\n");
  float a = 0;
  float b = 0;
  float c = 0;
  float x1 = 0;
  float x2 = 0;
  float d = 0;
  
  scanf("%f%f%f", &a, &b, &c);
  if (a == 0 && b == 0 && c == 0)
  {
    printf("Любое число");
    return 0;
  }
  else if (a == 0 && b == 0)
  {
    printf("Уравнение не имеет решения");
    return 0;
  }
  else if (a == 0)
  {
    x1 = -c / b;
    printf ("x1 = %.1f\n",x1);
    
    if ((int)x1 % 2 == 0){
      printf ("четное");
    } else {
      printf ("нечетное");
    } 
    return 0;
  }
  else 
  {
    d = b*b-4*a*c;
    if (d < 0)
  {
    printf ("Уравнение не имеет решения. D < 0.");
    return 0;
  }
  else if (d == 0)
  {
    x1 = -b / (2 * a);
    printf ("x1 = %.1f\n", x1);
    if ((int)x1 % 2 == 0){
      printf ("четное");
    } else {
      printf ("нечетное");
    }
    return 0;
  }
  else
  {
  x1 = -b + sqrt(d) / (2 * a);
  x2 = -b - sqrt(d) / (2 * a);
    printf ("x1 = %.1f\n", x1);
    if ((int)x1 % 2 == 0){
      printf ("четное");
    } else {
      printf ("нечетное");
    }
    printf ("\nx2 = %.1f\n", x2);
    if ((int)x2 % 2 == 0){
      printf ("четное");
    } else {
      printf ("нечетное");
    }
  }
  }
}
