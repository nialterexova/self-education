#include <stdio.h>
#include <stdlib.h>

int main (void) {
  printf ("Введите число от 0 до 23 и перезапустите программу\n");
  int a = 0;
  scanf("%i", &a);
  int p = 0,v = 0,b = 0,i = 0;
  if (a >= 0 && a <= 23) {
    printf ("Высота:");
    for (v = 0;v<=a-7;v++){
      printf (" ");
    }
   printf ("%i",a);
  for (i = 0; i<=a-2; i++){
    printf ("\n");
    for (p = 0;p<=a-i;p++)
       printf (" ");
      for (b = 0; b<=i+1; b++)
        printf ("#");
  }
} else {
    printf ("Введите правильное число!");
}
  return 0;
  }
