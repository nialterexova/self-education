# -cs50
if (age > 18) {
  printf("Доступ разрешён\n");
}
else
{
   printf("Доступ запрещён\n");
}