#include <stdio.h>

int main(void) {
  float sdach = 0;
  scanf("%f", &sdach);
  int monet = 0, monet25 = 0, monet10 = 0, monet5 = 0, monet1 = 0;
  int a = 25, b = 10, c = 5, d = 1;
  int cent = sdach * 100;
  if (sdach == 0) {
    printf ("Вам не нужна сдача");
    return 0;
  }
   while(sdach < 0)
        {
            printf ("Введите корректную сумму "); 
            return 0;
        } 
    while(cent >= 25)
        {
            cent = cent - 25;
            monet25 = monet25 + 1;
            monet = monet + 1;
        }
    while(cent >= 10)
        {
            cent = cent - 10;
             monet10 = monet10 + 1;
             monet = monet + 1;
        }
    while(cent >= 5)
        {
            cent = cent - 5;
             monet5 = monet5 + 1;
             monet = monet + 1;
        }
    while(cent > 0)
        {
            cent = cent - 1;
             monet1 = monet1 + 1;
             monet = monet + 1;
        }
    printf("На сдачу нужно %i монет\nКол-во монет по номиналу:\n", monet);
    printf("  25-ти центовых %i монет\n", monet25);
    printf("  10-ти центовых %i монет\n", monet10);
    printf("  5-ти центовых %i монет\n", monet5);
    printf("  1 центовых %i монет\n", monet1);
return 0;
}